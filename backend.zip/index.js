var express = require("express");
var app = express();
var cors = require("cors");
app.use(cors())

const mysql = require("mysql2");
const dbConfig = { 
  HOST: "127.0.0.1",
  USER: "root",
  PASSWORD: "Vivek",
  DB: "my_db",
  PORT:"3306"
}
// Create a connection to the database
var connection = mysql.createConnection({
  host: dbConfig.HOST,
  user: dbConfig.USER,
  password: dbConfig.PASSWORD,
  database: dbConfig.DB,
  port:dbConfig.PORT
});
// open the MySQL connection
connection.connect(error => {
  connection.query("SELECT * FROM student", function (err, result, fields) {
    if (err) throw err;
  });
  if (error) throw error;
  console.log("Successfully connected to the database.");
});

app.get('/login', async (req, res) => {
  var { student_id } = req.query
  await connection.query(`SELECT * FROM student WHERE student_id = ${student_id}`, function (err, result) {
    if (err) return res.json({
      status: "failure",
      result: err,
      message: "failed to retrieve",
    });
    return res.json({
      message: "success",
      response: result,
    });
  })
})

app.get("/dashboard", async (req, res) => {
  var { college_id } = req.query;
  await connection.query(
    `SELECT * FROM faculty WHERE college_id = ${college_id}`,
    function (err, result) {
      if (err)
        return res.json({
          status: "failure",
          result: err,
          message: "failed to retrieve",
        });
      return res.json({
        message: "success",
        response: result,
      });
    }
  );
});

app.get("/application", async (req, res) => {
  var { college_id } = req.query;
  await connection.query(
    `SELECT * FROM college WHERE ID = ${college_id}`,
    function (err, result) {
      if (err)
        return res.json({
          status: "failure",
          result: err,
          message: "failed to retrieve",
        });
      return res.json({
        message: "success",
        response: result,
      });
    }
  );
});

app.post("/dashboard", async (req, res) => {
  var { student_id } = req.query;
  await connection.query(
    `UPDATE student
  SET SOP_STATUS = "submitted"
  WHERE student_id=${student_id};`,
    function (err, result) {
      if (err)
        return res.json({
          status: "failure",
          result: err,
          message: "failed to retrieve",
        });
      return res.json({
        message: "success",
        response: result,
      });
    }
  );
});

app.post("/payment", async (req, res) => {
  var { student_id,faculty_id } = req.query;
  await connection.query(
    `INSERT INTO lor (STUDENT_ID, FACULTY_ID)
VALUES (${student_id}, ${faculty_id});`,
    function (err, result) {
      if (err)
        return res.json({
          status: "failure",
          result: err,
          message: "failed to retrieve",
        });
      return res.json({
        message: "success",
        response: result,
      });
    }
  );
});

app.post("/application", async (req, res) => {
  var { student_id, college_id } = req.query;
  console.log(req.body)
  await connection.query(
    `INSERT INTO i20 (STUDENT_ID, COLLEGE_ID)
VALUES (${student_id}, ${college_id});`,
    function (err, result) {
      if (err)
        return res.json({
          status: "failure",
          result: err,
          message: "failed to retrieve",
        });
      return res.json({
        message: "success",
        response: result,
      });
    }
  );
});

app.listen(5000, function () {
  console.log("Server is running.. on port : 5000");
});

module.exports = connection;