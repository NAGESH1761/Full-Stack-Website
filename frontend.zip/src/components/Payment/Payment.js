import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import '../Dashboard/dashboard.css'

export class Payment extends Component {
    state = {
        paymentsList: ["Credit cards", "UPI", "Loans", "Debit cards"],
        paymentDone:false
    }

    renderPaymentSuccess = () => {
        return (
          <div>
            <img
              src="https://res.cloudinary.com/dtg51opfy/image/upload/v1665931297/tick_bdk73x.png"
              alt="no img found"
              style={{ width: "100%", height: "100%" }}
            />
                <p>Payment Successful</p>
                <Link to="/application" >View I20 Application</Link>
          </div>
        );
    }

    renderPaymentList = () => {
        return <div><h1>Make Payment</h1>
            {this.state.paymentsList.map((each) => {
                return (
                    <div
                        style={{
                            borderRadius: 10,
                            backgroundColor: "#f5faf6",
                            padding: 10,
                            margin: 10,
                        }}
                    >
                        <button style={{ borderColor: "white" }} onClick={() => this.setState({ paymentDone: true })}>{each}</button>
                    </div>
                );
            })
        }
    </div>}
    
  render() {
    return (
      <div class="main">
            <div class="mini">
                {this.state.paymentDone ? this.renderPaymentSuccess() : this.renderPaymentList()}
          
        </div>
      </div>
    );
  }
}

export default Payment
