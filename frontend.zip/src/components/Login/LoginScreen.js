import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

import "./login.css";

function LoginScreen() {
  // React States
    let navigate = useNavigate()
    const [errorMessages, setErrorMessages] = useState(false);
    const [userId,setUserId] = useState("")
  
  // User Login info dummy data
  const handleSubmit = async (event) => {
    //Prevent page reload
    event.preventDefault();
    // Find user login info from dummy data
    await axios.get(`http://localhost:5000/login?student_id=${userId}`)
      .then((res) => {
        console.log(res)
        if (res.data.response[0]) {
        localStorage.setItem('student_id',userId)
        navigate("/dashboard");
      } else {
          setErrorMessages(true)
    }})
      .catch((err) => alert(err));    
  };

  // Generate JSX code for error message
  const renderErrorMessage = () =>
     {return (<div className="error"><p>User does not exist</p></div> );
}
  // JSX code for login form
  const renderForm = (
    <div className="form">
      <form onSubmit={handleSubmit}>
        <div className="input-container">
          <label>UserID </label>
          <input type="text" onChange={(event)=>setUserId(event.target.value)} required />
          {errorMessages && renderErrorMessage()}
        </div>
        <div className="button-container">
          <input type="submit" />
        </div>
      </form>
    </div>
  );

  return (
    <div className="app">
      <div className="login-form">
        <div className="title">Sign In</div>
        {renderForm}
      </div>
    </div>
  );
}

export default LoginScreen;
