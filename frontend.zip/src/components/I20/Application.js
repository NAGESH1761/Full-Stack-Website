import axios from 'axios';
import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import '../Dashboard/dashboard.css'


export class Application extends Component {

    state = {
        application: {
            name: "asdasd",
            email: "asdasda@asads.com",
            college: "asdsadasdasdasds",
            citizenship: "India",
            address : "asdasdasdasda,sdasdasdasd,asdasdasdfsdfsdf"
        },
        studentDetails: {},
        collegeDetails : {}
    }

    componentDidMount() {
        //API call to get application details from the application table on path "/application "
        this.getStudentDetails()
    }

    updateApplicationDetails = async() => {
        this.setState({
            application: {
                name: this.state.studentDetails.NAME,
                email: this.state.studentDetails.EMAIL,
                college: this.state.collegeDetails.NAME,
                citizenship: "India",
                address:this.state.collegeDetails.ADDRESS
            }
        })
        await axios
          .post(
            `http://localhost:5000/application?student_id=${this.state.studentDetails.ID}&college_id=${this.state.collegeDetails.ID}`,  
          )
          .then((res) => {
            if (res) {
              console.log(res);
            } else {
              alert("Please try again");
            }
          })
          .catch((err) => alert(err));
    }

    getStudentDetails=async() => {
        const student_id = localStorage.getItem("student_id")
        await axios
          .get(`http://localhost:5000/login?student_id=${student_id}`)
          .then((res) => {
            if (res) {
              this.setState({ studentDetails: res.data.response[0] });
            } else {
              alert("Please try again");
            }
          })
            .catch((err) => alert(err));
        this.getCollegeDetails();
    }

    getCollegeDetails = async () => {
        await axios
          .get(
            `http://localhost:5000/application?college_id=1001`
          )
          .then((res) => {
              if (res) {
              this.setState({collegeDetails:res.data.response[0]})
            } else {
              alert("Please try again");
            }
          });
        this.updateApplicationDetails()
    }

    render() {
        const { application } = this.state
    return (
      <div class="main">
        <div class="mini">
                <h1>Application form</h1>
                {
                    Object.keys(application).map((each) => {
                        return <div
                            style={{
                                flexDirection: "row",
                                display: "flex",
                                width: "60%",
                                justifyContent: "center",
                            }}
                        >
                            <p
                                style={{
                                    fontWeight: "bold",
                                    marginRight: 30,
                                    width: "20%",
                                    textTransform: "capitalize",
                                }}
                            >
                                {each}{" "}
                            </p>
                            <p style={{ width: "20%" }}>:</p>
                            <p style={{ width: "50%" }}>{application[each]}</p>
                        </div>
    
                    })
                }
                <Link to="/login">
                    <button onClick={()=>localStorage.clear()}>Logout</button>
                </Link>
        </div>
      </div>
    );
  }
}

export default Application