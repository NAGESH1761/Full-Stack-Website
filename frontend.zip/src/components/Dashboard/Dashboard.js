import React, { Component } from "react";
import { Link } from "react-router-dom";
import "./dashboard.css";
import axios from 'axios'

export default class dashboard extends Component {
  state = {
    studentDetails: {
      studentId: 1231243,
      name: "assads",
      email: "assdas@sads.com",
      CGPA: 9.3,
      TOEFL: 91,
      RANK: 10,
      GRE: 350,
      collegeID: 1001,
    },
    facultyList: ["faculty1", "faculty2", "faculty3", "faculty4"],
      selectedFaculty: "faculty",
      facultyObjects: []
  };

  componentDidMount() {
    this.getStudentDetails();
    this.getFacultyList();
  }

  getStudentDetails = async () => {
    //get api call to get student details on path /dashboard
    const student_id = localStorage.getItem("student_id");
    await axios
      .get(`http://localhost:5000/login?student_id=${student_id}`)
      .then((res) => {
        if (res) {
          this.setState({ studentDetails: res.data.response[0] });
        } else {
          alert("Please try again");
        }
      })
      .catch((err) => alert(err));
  };

  getFacultyList = async () => {
    //get api call to get faculty details on path /dashboard
    await axios
      .get(
        `http://localhost:5000/dashboard?college_id=${this.state.studentDetails.collegeID}`
      )
      .then((res) => {
        if (res) {
          const faculties = [];
          res.data.response.map((a) => faculties.push(a.NAME));
          this.setState({
            facultyList: faculties,
            selectedFaculty: faculties[0],
            facultyObjects : res.data.response
          });
        } else {
          alert("Please try again");
        }
      })
      .catch((err) => alert(err));
  };

  renderDetails = (a) => {
    const { studentDetails } = this.state;
    return (
      <div
        style={{
          flexDirection: "row",
          display: "flex",
          width: "60%",
          justifyContent: "center",
        }}
      >
        <p
          style={{
            fontWeight: "bold",
            marginRight: 30,
            width: "20%",
            textTransform: "capitalize",
          }}
        >
          {a}{" "}
        </p>
        <p style={{ width: "20%" }}>:</p>
        <p style={{ width: "50%" }}>{studentDetails[a]}</p>
      </div>
    );
  };

  onSelectingLOR = () => {
    var x = document.getElementById("LOR").value;
    this.setState({ selectedFaculty: x });
  };

    onClickingSOP = async () => {
        const student_id = localStorage.getItem("student_id");
        await axios
          .post(`http://localhost:5000/ ?student_id=${student_id}`)
          .then((res) => {
            if (res) {
              this.getStudentDetails()
            } else {
              alert("Please try again");
            }
          })
          .catch((err) => alert(err));
      alert("SOP successfully submitted");
    }

    onClickPayment = async () => {
        const faculty_id = this.state.facultyObjects.filter((each)=>each.NAME === this.state.selectedFaculty)
        
        await axios
          .post(
            `http://localhost:5000/dashboard?faculty_id=${faculty_id.ID}&student_id=${this.state.studentDetails.studentId}`
          )
          .then((res) => {
            if (res) {
              console.log(res);
            } else {
              alert("Please try again");
            }
          })
          .catch((err) => alert(err));
    }

  render() {
    const { studentDetails } = this.state;
    const isEligible =
          parseInt(studentDetails.CGPA) >= 8 && parseInt(studentDetails.TOEFL) > 79;
      const sopStatus = studentDetails.SOP_STATUS === "NA"
    return (
      <div class="main">
        <div class="mini">
          <h1>Student Details</h1>

          <div class="details">
            {Object.keys(this.state.studentDetails).map((a) =>
              this.renderDetails(a)
            )}
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "65%",
              height: 30,
                marginTop: 40,
              alignItems:'center'
            }}
          >
            {sopStatus ? <button onClick={() => this.onClickingSOP()}>SOP</button> : <h3>SOP already submitted</h3>}
            
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <h4>LOR :</h4>
              <select name="LOR" id="LOR" onChange={this.onSelectingLOR}>
                {this.state.facultyList.map((each) => {
                  return <option value={each}>{each}</option>;
                })}
              </select>
            </div>
          </div>

                {isEligible ? (
                    sopStatus ? <button onClick={() => { alert("Please submit SOP first") }}>Make Payment</button> : 
                        <Link to="/payment">
                            <button onClick={()=>{this.onClickPayment()}}>Make Payment</button>
                        </Link>
          ) : (
            <h3>We are sorry, you're ineligible</h3>
          )}
        </div>
      </div>
    );
  }
}
